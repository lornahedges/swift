//
//  ContentView.swift
//  SavannahLeeArt
//
//  Created by Lorna Hedges on 3/23/23.
//Helpful Notes: to extract Subview, highlight the piece of code you want to extract and press COMMAND CLICK

import SwiftUI
let backgroundColor = Color(red: 235.0/256.0, green: 218.0/256.0, blue: 204.0/256.0)
let textColor = Color(red: 228.0/256.0, green: 177.0/256.0, blue: 165.0/256.0)
let creamColor = Color(red: 242.0/256.0, green: 230.0/256.0, blue: 217.0/256.0)

struct ContentView: View {
    
    @State var username: String = ""
        //everytime the State property gets changed or updated, the view gets rerendered and displays the content depending on the state's data
    @State var password: String = ""
    @State var email: String = ""
    
    @State var AutheticationDidFail: Bool = false
    @State var AuthenticationDidSucceed: Bool = true
    
    @State var isLoginMode = true
    
    var body: some View {
        
        //all objects inside of ZStack gets stacked on top of each other
        ZStack {
            
            
            VStack {
                NavigationView {
                    ScrollView {
                        Picker(selection: $isLoginMode, label: Text("picker here")) {
                            Text("Login")
                                .tag(true)
                            Text("Create Account")
                                .tag(false)
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .padding()
                        .background(backgroundColor)
                        
                    }
                    
                    .navigationTitle(isLoginMode ? "Log in" : "Create Account")
                    .background(backgroundColor)
                }
                Logo()
                
                if(!isLoginMode){
                    EmailTextField(email: $email)
                }
                //username
                UsernameTextField(username: $username)
                
                //password
                PasswordSecureField(password: $password)
                if AutheticationDidFail {
                    Text("Your password does not match our records. Try Again.")
                        .offset(y: -10)
                        .foregroundColor(.red)
                }
                
                
                //Button() {
                    //LoginButton()
                NavigationLink(destination: HomeScreen()) {
                    LoginButton()
                    } 
                //}
            }
        
            .padding()
                //makes the username and password fields not touch the sides of the screen
            /*if AuthenticationDidSucceed {
                Text("Login Successful!")
                    .font(.headline)
                    .frame(width: 250, height: 20)
                    .offset(y: -30)
                    .background(Color.gray)
                    .cornerRadius(20)
            }*/
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .background(backgroundColor)
    }
}



struct Logo: View {
    var body: some View {
        Image("2023logopic")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: 250, height: 250)
            .clipped()
            .cornerRadius(15)
            .padding(.bottom, 10)
    }
}

struct LoginButton: View {
    var body: some View {
        Text("Login")
            .font(.headline)
            .foregroundColor(textColor)
            .padding()
            .frame(width: 220, height: 60)
            .background(creamColor)
            .cornerRadius(35)
    }
}

struct UsernameTextField: View {
    
    @Binding var username: String
    //bindings are used to create a data connection between a view and its source of data
    var body: some View {
        TextField("Username", text: $username)
        /*
         this is how the user sees what he has entered into a text field.
         to bind objects to state property, we have to pass the property's name with a $ in front as seen above.
         the text parameter is the default text in the textfield before it is updated
         */
            .padding()
            .background(creamColor)
            .cornerRadius(5.0)
            .padding(.bottom, 20)
    }
}

struct PasswordSecureField: View {
    
    @Binding var password: String
    var body: some View {
        SecureField("Password", text: $password)
            .padding()
            .background(creamColor)
            .cornerRadius(5.0)
            .padding(.bottom, 20)
    }
}

struct EmailTextField: View {
    
    @Binding var email: String
    
    var body: some View {
        TextField("Email Address", text: $email)
            .padding()
            .background(creamColor)
            .cornerRadius(5.0)
            .padding(.bottom, 20)
    }
}
