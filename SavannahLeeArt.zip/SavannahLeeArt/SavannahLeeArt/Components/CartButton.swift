//
//  CartButton.swift
//  SavannahLeeArt
//
//  Created by Lorna Hedges on 3/31/23.
//

import SwiftUI

struct CartButton: View {
    var numberOfProducts: Int
    var body: some View {
        ZStack(alignment: .topTrailing) {
            Image(systemName: "cart")
                .padding(.top, 5)
            
            if numberOfProducts > 0
            {
                Text("\(numberOfProducts)")
                    .font(.caption2).bold()
                    .foregroundColor(textColor)
                    .frame(width: 10, height: 10)
                    .background(backgroundColor)
                    .cornerRadius(50)
            }
        }
    }
}

struct CartButton_Previews: PreviewProvider {
    static var previews: some View {
        CartButton(numberOfProducts: 1)
    }
}
