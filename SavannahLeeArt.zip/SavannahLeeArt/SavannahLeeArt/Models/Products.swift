//
//  Products.swift
//  SavannahLeeArt
//
//  Created by Lorna Hedges on 3/31/23.
//

import Foundation

struct Product: Identifiable {
    var id = UUID()
    var name: String
    var image: String
    var price: Int
}

var productList = [Product(name: "Campfire", image: "Fire", price: 360),
                   Product(name: "Avo", image: "Avo", price: 150),
                   Product(name: "Balloon Girl", image: "BalloonGirl2", price: 360),
                   Product(name: "Ciao Skateboard", image: "CiaoSkateboard", price: 200),
                   Product(name: "Purple Flowers", image: "Flowers", price: 360),
                   Product(name: "Green and Gold", image: "GreenandGold", price: 100),
                   Product(name: "Lighter", image: "Lighter", price: 150),
                   Product(name: "Red and Gold", image: "redandgold", price: 100),
                   Product(name: "Surfer", image: "Surfer", price: 80),
                   Product(name: "Whoop Skateboard", image: "WhoopSkateboard", price: 200),
                   Product(name: "Woods", image: "woods", price: 50),
                   







]
