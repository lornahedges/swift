//
//  SavannahLeeArtApp.swift
//  SavannahLeeArt
//
//  Created by Lorna Hedges on 3/23/23.
//

import SwiftUI

@main
struct SavannahLeeArtApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
