//
//  SessionManager.swift
//  SavannahLeeArt
//
//  Created by Lorna Hedges on 4/26/23.
//

import Foundation

final class SessionManager: ObservableObject {
    
    enum CurrentState {
        case loggedIn
        case loggedOut
    }
    
    //private(set) means that you cannot modify the variable outside of the scope.
    @Published private(set) var currentState: CurrentState?
    
    func signIn() {
        currentState = .loggedIn
    }
    
    func signOut() {
        currentState = .loggedOut
    }
}
