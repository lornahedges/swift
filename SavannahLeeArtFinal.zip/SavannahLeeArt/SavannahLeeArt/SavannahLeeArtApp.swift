//
//  SavannahLeeArtApp.swift
//  SavannahLeeArt
//
//  Created by Lorna Hedges on 3/23/23.
//

import SwiftUI
import Firebase

@main
struct SavannahLeeArtApp: App {
    
    @StateObject private var session = SessionManager()
    
    init() {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            switch session.currentState {
            case .loggedIn:
                HomeScreen()
                    .environmentObject(session)
                    .background(backgroundColor)
                    .transition(.opacity)
            default:
                LoginView()
                    .environmentObject(session)
                    .background(backgroundColor)
                    .transition(.opacity)
                
            }
        }
    }
}
