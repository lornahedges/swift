//
//  CartManager.swift
//  SavannahLeeArt
//
//  Created by Lorna Hedges on 3/31/23.
//

import Foundation

//observableObject protocol ensures that this class will be updated automatically in the UI
class CartManager: ObservableObject {
    //these variables can only be set within this class
    @Published private(set) var products: [Product] = []
    @Published private(set) var total: Int = 0
    
    func addToCart(product: Product) {
        products.append(product)
        total += product.price
    }
    
    func removeFromCart(product: Product) {
        //removes one if there are duplicates
        if let removeProduct = products.firstIndex(where: {$0.id == product.id}) {
                    products.remove(at: removeProduct)
                }

        total -= product.price
    }
}
