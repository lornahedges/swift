//
//  HomeScreen.swift
//  SavannahLeeArt
//
//  Created by Lorna Hedges on 3/31/23.
//

import SwiftUI
import Firebase

struct HomeScreen: View {
    @StateObject var cartManager = CartManager()
    var columns = [GridItem(.adaptive(minimum: 160), spacing: 20)]
    @State private var userIsLoggedIn = true
    
    
    var body: some View {
        NavigationView {
                ScrollView {
                    ZStack {
                        LazyVGrid(columns: columns, spacing: 20) {
                            ForEach(productList, id: \.id)
                            {
                                product in ProductCard(product: product)
                                    .environmentObject(cartManager)
                            }
                        }
                        //this makes the plus button not work for the product cards
                        //TabView {
                           // HomeScreen()
                            //.tabItem {
                                //Text("Home")
                            //}
                        //}
                        .padding()
                        
                    }
                }
                
                .navigationTitle(Text("Gallery"))
                .toolbar {
                    //  ToolbarItemGroup(placement: .navigationBarLeading) {
                    //sign out button
                    //  NavigationLink(destination: LoginView())
                    //  {
                    //  SignoutButton()
                    
                    //   }
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button() {
                            logOut()
                        } label:
                        {
                            SignoutButton()
                        }
                    }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        NavigationLink(destination: CartView().environmentObject(cartManager)) {
                            CartButton(numberOfProducts: cartManager.products.count)
                        }
                    }
                    /*
                     //cart image button
                     NavigationLink{
                     CartView()
                     .environmentObject(cartManager)
                     
                     } label: {
                     CartButton (numberOfProducts: cartManager.products.count)
                     }
                     }
                     // }*/
                }
        }
            
            
                .navigationViewStyle(StackNavigationViewStyle())
                
            }
            
    func logOut() {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print("Error signing out: %@", signOutError)
        }
    }

}

struct SignoutButton: View {
    var body: some View {
        Text("Sign out")
            .font(.headline)
            .foregroundColor(textColor)
            .frame(width: 220, height: 60)
            .background(creamColor)
            .cornerRadius(35)
    }
        
}

struct HomeScreen_Previews: PreviewProvider {
    static var previews: some View {
        HomeScreen()
    }
}
