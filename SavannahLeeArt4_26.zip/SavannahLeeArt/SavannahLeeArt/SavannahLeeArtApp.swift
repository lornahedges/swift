//
//  SavannahLeeArtApp.swift
//  SavannahLeeArt
//
//  Created by Lorna Hedges on 3/23/23.
//

import SwiftUI
import Firebase

@main
struct SavannahLeeArtApp: App {
    
    init() {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            NavigationView {
                LoginView()
                    .background(backgroundColor)
            }
        }
    }
}
